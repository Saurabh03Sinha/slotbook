import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { IANAZone } from 'luxon';
import { pool } from '../../db/client.js';
import { resolveAuthenticatedHost } from '../../plugins/auth.js';
import { AppError } from '../../plugins/errors.js';

const UpdateTimezoneSchema = z.object({
  timeZone: z.string().min(1),
  name: z.string().min(1).optional(),
});

export async function registerHostRoutes(app: FastifyInstance) {
  // Get authenticated host profile
  app.get('/api/host/me', async (req) => {
    return resolveAuthenticatedHost(req);
  });

  // 1. Set a home time zone (IANA, e.g. Asia/Kolkata, America/New_York)
  app.patch('/api/host/settings', async (req) => {
    const host = await resolveAuthenticatedHost(req);
    const body = UpdateTimezoneSchema.parse(req.body);

    if (!IANAZone.isValidZone(body.timeZone)) {
      throw new AppError(
        400,
        `Invalid IANA time zone: ${body.timeZone}`,
        'INVALID_TIMEZONE'
      );
    }

    const res = await pool.query(
      `UPDATE hosts
       SET time_zone = $2,
           name = COALESCE($3, name)
       WHERE id = $1
       RETURNING id, username, email, name, time_zone AS "timeZone"`,
      [host.id, body.timeZone, body.name ?? null]
    );

    return res.rows[0];
  });
}
